# project-name

Find name of the actual project. Firstly searching README.md and REAMDE files
and their first row which is not empty. IF readme doesn't exists then searching
for project name in the actual repository.
